package com.unicamp.mc322.lab07;

public class ResidenciaCasa extends Residencias{
	
	private int n_quartos_casa;
	private int n_banheiros_casa;
	private boolean piscina;

	/**
	 * define os parametros para a subclasse casa
	 * @param nome
	 * @param coordenadas
	 * @param aluguel
	 * @param n_quartos_casa
	 * @param n_banheiros_casa
	 * @param piscina
	 */
	public ResidenciaCasa(String nome, int x, int y, int aluguel, int n_quartos_casa, int n_banheiros_casa, boolean piscina) {
		super(nome, x, y, aluguel);
		this.n_quartos_casa = n_quartos_casa;
		this.n_banheiros_casa = n_banheiros_casa;
		this.piscina = piscina;
	}

	/**
	 * retorna o numero de quartos na casa
	 * @return
	 */
	public int getNQuartosCasa() {
		return n_quartos_casa;
	}
	
	/**
	 * retorna o numero de banheiros que a casa possui
	 * @return
	 */
	public int getNBanheirosCasa() {
		return n_banheiros_casa;
	}
	
	/**
	 * retorna true se a casa tem piscina e false se nao tiver
	 * @return
	 */
	public boolean getPiscina() {
		return piscina;
	}
	
	
	/**
	 * imprime tudo a respeito da casa
	 * @param r
	 */
	public void printCasa(ResidenciaCasa r) {
		System.out.println("Nome: " + r.getNome());
		System.out.println("Posicao: " + r.getPosicaoRes());
		System.out.println("Aluguel: " + r.getAluguel());
		System.out.println("Numero de quartos: " + r.getNQuartosCasa());
		System.out.println("Numero de banheiros: " + r.getNBanheirosCasa());
		if (r.getPiscina() == true) {
			System.out.println("Possui piscina");
		}
		else {
			System.out.println("Nao possui piscina");
		}
		System.out.println();
	}
}
