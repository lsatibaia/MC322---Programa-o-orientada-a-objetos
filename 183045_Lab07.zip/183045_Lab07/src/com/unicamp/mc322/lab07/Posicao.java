package com.unicamp.mc322.lab07;

public class Posicao {
	private int x_posicao;
	private int y_posicao;
	
	
	/**
	 * define o x e y de uma posicao, sendo eles os valores de entrada
	 * @param x
	 * @param y
	 */
	public void Posicao(int x, int y) {
		this.x_posicao = x;
		this.y_posicao = y;
	}
	
	/**
	 * retorna o valor x de uma posicao
	 * @return
	 */
	public int getPosicaoX() {
		return x_posicao;
	}
	
	/**
	 * retorna o valor y de uma posicao
	 * @return
	 */
	public int getPosicaoY() {
		return y_posicao;
	}


}
