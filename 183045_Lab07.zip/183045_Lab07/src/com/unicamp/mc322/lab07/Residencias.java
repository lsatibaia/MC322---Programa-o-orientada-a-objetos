package com.unicamp.mc322.lab07;

public abstract class Residencias {
	private String nome;
	private Posicao coordenadas;
	private int aluguel;
	
	/**
	 * define os parametros da super classe residencias
	 * @param nome
	 * @param coordenadas
	 * @param aluguel
	 */
	public Residencias(String nome,int x, int y, int aluguel) {
		this.nome = nome;
		this.coordenadas.Posicao(x, y);
		this.aluguel = aluguel;
	}
	
	/**
	 * retorna o nome da residencia em questao
	 * @return
	 */
	public String getNome() {
		return this.nome;
	}
	
	/**
	 * retorna o endereco/posicao da residencia
	 * @return
	 */
	public Posicao getPosicaoRes() {
		return this.coordenadas;
	}
	
	/**
	 * retorna o valor da aluguel por um dia da residencia
	 * @return
	 */
	public int getAluguel() {
		return this.aluguel;
	}

}
