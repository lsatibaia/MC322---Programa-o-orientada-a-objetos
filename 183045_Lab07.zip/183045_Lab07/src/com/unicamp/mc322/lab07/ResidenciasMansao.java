package com.unicamp.mc322.lab07;

public class ResidenciasMansao extends Residencias{

	private int metros_quadrados;
	
	/**
	 * define os parametros da subclasse mansao
	 * @param nome
	 * @param coordenadas
	 * @param aluguel
	 * @param metros_quadrados
	 */
	public ResidenciasMansao(String nome, int x, int y, int aluguel, int metros_quadrados) {
		super(nome, x, y, aluguel);
		this.metros_quadrados = metros_quadrados;
	}
	
	/**
	 * retorna a area da mansao
	 * @return
	 */
	public int getMetrosQuadrados() {
		return metros_quadrados;
	}


	/**
	 * imprime tudo a respeito da mansao
	 * @param r
	 */
	public void printMansao(ResidenciasMansao r) {
		System.out.println("Nome: " + r.getNome());
		System.out.println("Posicao: " + r.getPosicaoRes());
		System.out.println("Aluguel: " + r.getAluguel());
		System.out.println("Metros quadrados: " + r.getMetrosQuadrados());
		System.out.println();
	}

}
