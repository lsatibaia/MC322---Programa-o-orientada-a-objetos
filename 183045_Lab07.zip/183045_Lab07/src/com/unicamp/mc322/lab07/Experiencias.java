package com.unicamp.mc322.lab07;

public class Experiencias {
	private Posicao coordenadas;
	private int n_max;
	private int preco_adulto;
	private int preco_menores;
	
	/**
	 * define os paramentros necessarios da experiencia
	 * @param coordenadas
	 * @param n_max
	 * @param preco_adulto
	 * @param preco_menores
	 */
	public Experiencias(int x, int y, int n_max, int preco_adulto, int preco_menores) {
		this.coordenadas.Posicao(x, y);
		this.n_max = n_max;
		this.preco_adulto = preco_adulto;
		this.preco_menores = preco_menores;
	}
	
	/**
	 * retorna a posicao da experiencia
	 * @return
	 */
	public Posicao getPosicaoExp() {
		return this.coordenadas;		
	}
	
	/**
	 * retorna o numero maximo de pessoas
	 * @return
	 */
	public int getNMax() {
		return this.n_max;
	}
	
	/**
	 * retorna o preco do adulto
	 * @return
	 */
	public int getPrecoAdulto() {
		return this.preco_adulto;
	}
	
	/**
	 * retorna o preco pra menores de idade
	 * @return
	 */
	public int getPrecoMenores() {
		return this.preco_menores;
	}
	
	
	/**
	 * imprime tudo a respeito da experiencia
	 * @param r
	 */
	public void printExperiencia(Experiencias e) {
		System.out.println("Posicao: " + e.getPosicaoExp());
		System.out.println("Numero maximo de pessoas: " + e.getNMax());
		System.out.println("Preco base: " + e.getPrecoAdulto());
		System.out.println("Preco com desconto para menor de idade: " + e.getPrecoMenores());
		System.out.println();
	}

}
