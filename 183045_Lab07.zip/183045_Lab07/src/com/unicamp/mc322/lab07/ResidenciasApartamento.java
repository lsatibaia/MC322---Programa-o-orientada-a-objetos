package com.unicamp.mc322.lab07;

public class ResidenciasApartamento extends Residencias {
	
	private int n_quartos;
	private int n_banheiros;
	private int andar;
	private boolean sacada;
	
	/**
	 * define os parametros de um subclasse apartamento
	 * @param nome
	 * @param coordenadas
	 * @param aluguel
	 * @param n_quartos
	 * @param n_banheiros
	 * @param andar
	 * @param sacada
	 */
   public ResidenciasApartamento(String nome, int x, int y, int aluguel, int n_quartos, int n_banheiros, int andar, boolean sacada) {
		super(nome, x, y, aluguel);
		this.n_quartos = n_quartos;
		this.n_banheiros = n_banheiros;
		this.andar = andar;
		this.sacada = sacada;
	}
   
   /**
    * retorna o numero de quartos em no apartamento em questao
    * @return
    */
   public int getNQuartos(){
	   return this.n_quartos;
   }
   
   /**
    * retorna o numero de banheiros no apartamento em questao
    * @return
    */
   public int getNBanheiros() {
	   return this.n_banheiros;
   }
   
   /**
    * retorna o andar que se encontra o apartamento
    * @return
    */
   public int getAndar() {
	   return this.andar;
   }
   
   /**
    * retorna true se o apartamento tiver sacada e false se nao tiver
    * @return
    */
   public boolean getSacada() {
	   return this.sacada;
   }
   
   
   /**
    * imprime tudo a respeito do apartamento
    * @param r
    */
   public void printApartamento(ResidenciasApartamento r) {
		System.out.println("Nome: " + r.getNome());
		System.out.println("Posicao: " + r.getPosicaoRes());
		System.out.println("Aluguel: " + r.getAluguel());
		System.out.println("Numero de quartos: " + r.getNQuartos());
		System.out.println("Numero de banheiros: " + r.getNBanheiros());
		System.out.println("Andar: " + r.getAndar());
		if (r.getSacada() == true) {
			System.out.println("Possui sacada");
		}
		else {
			System.out.println("Nao possui sacada");
		}
		System.out.println();
	}

   
}
