package com.unicamp.mc322.lab07;

import java.util.LinkedList;
import java.util.List;

public class AirPOO {
	
	private List<Reserva> reservas;
	private List<Residencias> residencias;
	private List<Experiencias> experiencias;
	private double valor_total;
	
	public AirPOO() {
		this.residencias = new LinkedList<>();
		this.reservas = new LinkedList<>();
		this.experiencias = new LinkedList<>();
	}
	 
	
	/**
	 * a primeira adiciona e a segunda remove a residencia criada na lista de residencias
	 * @param r
	 */
	public void addResidencias(Residencias r) {
		this.residencias.add(r);
	}
	public void removerResidencias(Residencias r) {
		this.residencias.remove(r);
	}
	
	
	/**
	 * a primeira adiciona e a segunda remove a experiencia criada na lista de experiencias
	 * @param exp
	 */
	public void addExperiencias(Experiencias exp) {
		this.experiencias.add(exp);
	}
	public void removerExperiencias(Experiencias exp) {
		this.experiencias.remove(exp);
	}

	
	/**
	 * a primeira adiciona e a segunda remove uma reserva na lista de experiencias
	 * @param re
	 */
	public void addReservas(Reserva re) {
		this.reservas.add(re);
		this.valor_total = this.valor_total + re.getPreco();
	}
	public void removerReservas(Reserva re) {
		this.reservas.remove(re);
		this.valor_total = this.valor_total - re.getPreco();
	}
	
	
	/**
	 * imprime o valor total no final das reservas
	 * @return
	 */
	public void printValorTotal() {
		System.out.println(this.valor_total);
	}
}
