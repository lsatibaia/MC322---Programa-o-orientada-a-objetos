package com.unicamp.mc322.lab07;

public class ResidenciasRedes extends Residencias {

	/**
	 * define os dados da subclasse rede
	 * @param nome
	 * @param coordenadas
	 * @param aluguel
	 */
	public ResidenciasRedes(String nome,int x, int y, int aluguel) {
		super(nome, x, y, aluguel);
	}
		

	/**
	 * imprime tudo a respeito da rede
	 * @param r
	 */
	public void printRedes(ResidenciasRedes r) {
		System.out.println("Nome: " + r.getNome());
		System.out.println("Posicao: " + r.getPosicaoRes());
		System.out.println("Aluguel: " + r.getAluguel());
		System.out.println();
	}
}
