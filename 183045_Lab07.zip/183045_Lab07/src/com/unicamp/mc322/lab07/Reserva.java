package com.unicamp.mc322.lab07;

import java.lang.Math;

public class Reserva {

	private Residencias r;
	private Experiencias e;
	private int n_total_pessoas;
	private int n_menores;
	private int n_dias;
	private double preco;
	
	
	/**
	 * faz a reserva em um apartamento
	 * @param r
	 * @param n_total
	 * @param n_menores
	 * @param n_dias
	 */
	public void ReservaApartamento(ResidenciasApartamento r, int n_total, int n_menores, int n_dias) {
		this.r = r;
		this.n_total_pessoas = n_total;
		this.n_menores = n_menores;
		this.n_dias = n_dias;
		this.preco = precoApartamento(r);
	}
	/**
	 * retorna o preco da reserva
	 * @param r
	 * @return
	 */
	public double precoApartamento(ResidenciasApartamento r) {
		double x = 0;
		
		x = this.n_dias * r.getAluguel();
		x = x * (1 + (r.getAndar()));
		
		if(r.getSacada() == true) {
			x = x + r.getAluguel();
		}
		
		return x;
	}
	

	/**
	 * reserva em uma casa
	 * @param r
	 * @param n_total
	 * @param n_menores
	 * @param n_dias
	 */
	public void ReservaCasa(ResidenciaCasa r, int n_total, int n_menores, int n_dias) {
		this.r = r;
		this.n_total_pessoas = n_total;
		this.n_menores = n_menores;
		this.n_dias = n_dias;
		this.preco = precoCasa(r);
	}
	
	/**
	 * retorna o preco da reserva da casa
	 * @param r
	 * @return
	 */
	public double precoCasa(ResidenciaCasa r) {
		double x = 0;
		
		x = (r.getNBanheirosCasa() / r.getNQuartosCasa()) * r.getAluguel();
		
		if(r.getPiscina() == true) {
			if(this.n_dias <= 7) {
				x = x + (this.n_dias * r.getAluguel());
			}
			else {
				x = x + (7 * r.getAluguel());
			}
		}
		
		return x;
	}
	
	
	/**
	 * faz a reserva em uma mansao
	 * @param r
	 * @param n_total
	 * @param n_menores
	 * @param n_dias
	 */
	public void ReservaMansao(ResidenciasMansao r, int n_total, int n_menores, int n_dias) {
		this.r = r;
		this.n_total_pessoas = n_total;
		this.n_menores = n_menores;
		this.n_dias = n_dias;
		this.preco = precoMansao(r);
	}
	
	/**
	 * retorna o preco da reserva
	 * @param r
	 * @return
	 */
	public double precoMansao(ResidenciasMansao r) {
		double x = 0;
		
		x = Math.pow((100 * this.n_total_pessoas / r.getMetrosQuadrados()),(this.n_dias - 1));
		x = x * r.getAluguel();
		
		return x;
	}
	
	
	/**
	 * faz a reserva em uma rede
	 * @param r
	 * @param n_total
	 * @param n_menores
	 * @param n_dias
	 */
	public void ReservaRede(ResidenciasRedes r, int n_total, int n_menores, int n_dias) {
		this.r = r;
		this.n_total_pessoas = n_total;
		this.n_menores = n_menores;
		this.n_dias = n_dias;
		this.preco = precoRede(r);
	}
	
	/**
	 * retorna o preso da reserva
	 * @param r
	 * @return
	 */
	public double precoRede(ResidenciasRedes r) {
		double x = 0;
		
		if(n_dias <= 5) {
			x = r.getAluguel() * this.n_dias * this.n_total_pessoas;
		}
		
		return x;
	}
	
	
	/**
	 * faz a reserva em uma experiencia
	 * @param e
	 * @param n_total
	 * @param n_menores
	 * @param n_dias
	 * @return 
	 */
	public void ReservaExperiencia(Experiencias e, int n_total, int n_menores, int n_dias) {
		this.e = e;
		this.n_total_pessoas = n_total;
		this.n_menores = n_menores;
		this.n_dias = n_dias;
		this.preco = precoExperiencias(e);
	}
	
	/**
	 * retorna o valor da reserva
	 * @param e
	 * @return
	 */
	public double precoExperiencias(Experiencias e) {
		double x = 0;
		
		if(this.n_total_pessoas <= e.getNMax()) {
			x = (this.n_total_pessoas - this.n_menores) * e.getPrecoAdulto();
		    x = x + (this.n_menores * e.getPrecoMenores());
		}
		
		return x;
	}
	
	public Residencias getResid() {
		return this.r;
	}
	
	public Experiencias getExp() {
		return this.e;
	}
	
	public int getNTotal() {
		return this.n_total_pessoas;
	}
	
	public int getNMenores() {	
		return this.n_menores;
	}
	
	public int getNDias() {
		return this.n_dias;
	}
	
	public double getPreco() {
		return this.preco;
	}
}
