package com.unicamp.mc322.lab07;

public class PontosDeInteresse {

	private String local;
	private Posicao posicao;
	
	public PontosDeInteresse(String nome, int x, int y) {
		this.local = nome;
		this.posicao.Posicao(x, y);
	}

	

}
