package com.unicamp.mc322.lab04;

public class Idade {

}
