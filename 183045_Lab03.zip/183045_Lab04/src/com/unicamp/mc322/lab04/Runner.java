package com.unicamp.mc322.lab04;

public class Runner {
	public static void main(String[] args) {
		VacinaCovid app = new VacinaCovid();
	    app.setIdadeMinimaAtendida(60);
	    
	    app.cadastrarUsuario("Jose da Silva", "123.456.789-01", new LocalDate(1960,12,03), new Endere�o(10,30));
	}

	
	
}
