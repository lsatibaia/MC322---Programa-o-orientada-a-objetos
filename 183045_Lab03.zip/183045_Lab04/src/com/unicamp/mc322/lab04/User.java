package com.unicamp.mc322.lab04;

import java.time.LocalDate;

public class User {
	private String nome;
	private String cpf;
	private LocalDate aniversario;
	private Endere�o endereco;
	private boolean agendado;
	
	public User(String nome, String cpf, LocalDate aniversario, Endere�o endereco) {
		this.setNome(nome);
		this.setCPF(cpf);
		this.setAniversario(aniversario);
		this.setEndereco(endereco);
		this.setAgendado(false);
	}
	
	public String getNome() {
		return nome;
	}
	
	public String getCPF() {
		return cpf;
	}
	
	public LocalDate getAniversario() {
		return aniversario;
	}
	
	public boolean getAgendado() {
		return agendado;
	}
	
	public Endere�o getEndereco() {
		return endereco;
	}
	
	public int getEnderecoXX() {
		int x = endereco.getEnderecoX();
		return x;
	}
	
	public int getEnderecoYY() {
		int y = endereco.getEnderecoY();
		return y;
	}
	
	//chega na idade do usuario e retorna ela
	public int getIdade() {
		int idade;
		idade = LocalDate.now().getYear() - aniversario.getYear();
		if(LocalDate.now().getMonthValue() < aniversario.getMonthValue()) {
			return idade - 1;
		}
		if(LocalDate.now().getMonthValue() > aniversario.getMonthValue()) {
			return idade;
		}
		if(LocalDate.now().getMonthValue() == aniversario.getMonthValue()) {
			if(LocalDate.now().getDayOfMonth() < aniversario.getDayOfMonth()) {
				return idade - 1;
			}
			if(LocalDate.now().getDayOfMonth() >= aniversario.getDayOfMonth()) {
				return idade;
			}
		}
		return idade;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	public void setCPF(String cpf) {
		this.cpf = cpf;
	}
	public void setAniversario(LocalDate aniversario) {
		this.aniversario = aniversario;
	}
	public void setEndereco(Endere�o endereco) {
		this.endereco = endereco;
	}
	public void setAgendado(boolean a) {
		this.agendado = a;
	}

    
}
