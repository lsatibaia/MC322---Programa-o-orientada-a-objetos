package com.unicamp.mc322.lab04;

public class Endere�o {
	private int enderecoX;
	private int enderecoY;
	
	public void Endereco(int x, int y) {
		this.enderecoX = x;
		this.enderecoY = y;
	}
	
	public int getEnderecoX() {
		return enderecoX;
	}
	
	public int getEnderecoY() {
		return enderecoY;
	}

	
	
}
