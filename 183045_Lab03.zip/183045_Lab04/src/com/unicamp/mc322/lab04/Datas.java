package com.unicamp.mc322.lab04;

public class Datas {
	private static int idadeMinimaAtendida;
	
	public void setIdadeMinimaAtendida(int i) {
		idadeMinimaAtendida = i;
	}
	
	public static int getIdadeMinimaAtendida() {
		return idadeMinimaAtendida;
	}
	

}
