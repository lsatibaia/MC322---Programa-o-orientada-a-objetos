package com.unicamp.mc322.lab04;

public class Agenda { //estrutura da agenda que sera usada em cada um dos hospitais para o agendamento de pessoas
	private int idadeMinima;
	private Hospital hospital;
	private User user;
	protected boolean dispon;
    protected DiasDaSemana dias;
    
	public boolean dispon() {
		return dispon;
	}
	
}
