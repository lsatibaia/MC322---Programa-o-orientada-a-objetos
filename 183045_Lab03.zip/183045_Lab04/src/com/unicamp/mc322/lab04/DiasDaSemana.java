package com.unicamp.mc322.lab04;


public enum DiasDaSemana {
	Segunda, Ter�a, Quarta, Quinta, Sexta, S�bado, Domingo
}



