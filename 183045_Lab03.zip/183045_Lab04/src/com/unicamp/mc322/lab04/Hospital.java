package com.unicamp.mc322.lab04;

public class Hospital {
	private DiasDaSemana Segunda;
	private DiasDaSemana Ter�a;
	private DiasDaSemana Quarta;
	private String nome;
	private Endere�o endereco;
	private int quant;
	private Agenda[] agenda;
	
	
	public Hospital(String nome, Endere�o endereco, int quant) {
		this.nome = nome;
		this.endereco = endereco;
		
	}
	
	public void agenda(int quant) {
		agenda = new Agenda[3*quant]; //cada agenda tem tres vezes a capacidade de um um dia pois estamos levando em conta a semana do hospital, logo como ele s� pode funcionar tres vezes na semana, usamos vezes tres.
		for(int i = 0; i < quant; i++) {
			agenda[i] = new Agenda();
			agenda[i].dias = Segunda;
			agenda[i].dispon = true;
		}
		for(int i = quant; i < 2*quant; i++) {
			agenda[i] = new Agenda();
			agenda[i].dias = Ter�a;
		}
		for(int i = 2*quant; i < 3*quant; i++) {
			agenda[i] = new Agenda();
			agenda[i].dias = Quarta;
		}
	}
	
	public boolean agendaDisp(int numero) {
		return agenda[numero].dispon();
	}
	
	public String getNome() {
		return nome;
	}
	
	public Endere�o getEndereco() {
		return endereco;
	}
	
	public int getDispon() {
		int x = 0;
		while((agenda[x].dispon != true) && (x < quant)) {
			x++;
		}
		if(x == quant) {
			return -1;
		}
		else {
			agenda[x].dispon = false;
			return x;
		}
		
	}
	
	public int getDisponPerto() {
		int x = 0;
		while((agenda[x].dispon != true) && (x < quant)) {
			x++;
		}
		if(x == quant) {
			return -1;
		}
		else {
			return x;
		}
	}
	
	public DiasDaSemana getDiasDaSemana(int ag) {
		return agenda[ag].dias;
	}
	
	public void setNomeH(String nome) {
		this.nome = nome;
	}
	public void setEnderecoH(Endere�o endereco) {
		this.endereco = endereco;
	}

	
	public int getEnderecoXXH() {
		int x = endereco.getEnderecoX();
		return x;
	}
	
	public int getEnderecoYYH() {
		int y = endereco.getEnderecoY();
		return y;
	}
	
	public void dia() {
		System.out.println(agenda[0].dias + ", " + agenda[quant].dias + ", " + agenda[2*quant].dias);
	}
	
	public void vagas() {
		int n = 0;
		int o = 0;
		int p = 0;
		for(int i = 0; i < quant; i++) {
			if(agenda[i].dispon = true) {
				n++;
			}
		}
		for(int i = quant; i < 2*quant; i++) {
			if(agenda[i].dispon = true) {
				o++;
			}
		}
		for(int i = 2*quant; i < 3*quant; i++) {
			if(agenda[i].dispon = true) {
				p++;
			}
		}
		System.out.println(n + " vagas disponiveis na " + agenda[0].dias + ", " + o + " vagas disponiveis na " + agenda[0].dias + ", " + p  + " vagas disponiveis na " + agenda[0].dias);
	}
}
