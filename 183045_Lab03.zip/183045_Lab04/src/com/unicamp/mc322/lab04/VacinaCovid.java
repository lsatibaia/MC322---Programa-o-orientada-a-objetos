package com.unicamp.mc322.lab04;

import java.time.LocalDate;

public class VacinaCovid {
	private int idadeMinima = 0;
	private User[] usuarios;
	private Hospital[] postos;
	private int a = 0; //numero de pessoas cadastradas
	private int p = 0; //numero de postos cadastrados
	
	public void setIdadeMinimaAtendida(int i) {
		idadeMinima = i;
	}
	
	public int getIdadeMinimaAtendida() {
		return idadeMinima;
	}
	
	//permite cadatrar os usuarios, salvando seus dados dentro de um array
	public void cadastrarUsuario(String nome, String cpf, LocalDate aniversario, Endere�o endereco) {
		if(a == 0) {
			usuarios = new User[100];
		}
		usuarios[a].setNome(nome);
		usuarios[a].setCPF(cpf);
		usuarios[a].setAniversario(aniversario);
		usuarios[a].setEndereco(endereco);
		usuarios[a].setAgendado(false);
		
		a++;
	}
	
	//permite cadastrar os postos, salvando os seus dados em um array
	public void cadastrarPosto(String nome, Endere�o endereco, int quant) {
		if(p == 0) {
			postos = new Hospital[10];
		}
		postos[p].setNomeH(nome);
		postos[p].setEnderecoH(endereco);
		postos[p].agenda(quant);
		p++;
	}
	
	//realiza o agendamento no posto especificado
	public void agendar(String nome, Hospital hospital) {
		for(int i=0; i<a; i++) {
			if(nome.equals(usuarios[i].getNome()) == true) {
				if(usuarios[i].getIdade() > getIdadeMinimaAtendida()) {
					if(usuarios[i].getAgendado() == false) {
						int ag = hospital.getDispon();
						if(ag != -1) {
							usuarios[i].setAgendado(true);
							
							System.out.println("Comprovante de agendamento");
							System.out.println(usuarios[i].getCPF());
							System.out.println(hospital.getNome());
							System.out.println(hospital.getDiasDaSemana(ag));
						}	
					}
				}
			}
		}
	}
	
	//realiza o agendamento no posto mais perto da pessoa
	public void agendarPerto(String cpf) {
		int h = 0;
		for(int i=0; i<a; i++) {
			if(cpf.equals(usuarios[i].getCPF()) == true) {
				if(usuarios[i].getIdade() > getIdadeMinimaAtendida()) {
					if(usuarios[i].getAgendado() == false) {
						
						for(int t = 0; t < p; t++) {
							int x = (usuarios[i].getEnderecoXX() - postos[p].getEnderecoXXH()) * (usuarios[i].getEnderecoXX() - postos[p].getEnderecoXXH());
							int y = (usuarios[i].getEnderecoYY() - postos[p].getEnderecoYYH()) * (usuarios[i].getEnderecoYY() - postos[p].getEnderecoYYH());
							int dist = (int) Math.sqrt(x + y);
							int menor = 10000;
							if(dist < menor) {
								h = t;
								menor = dist;
							}
						}
						
						int ag = postos[h].getDispon();
						if(ag != -1) {
							usuarios[i].setAgendado(true);
							
							System.out.println("Comprovante de agendamento");
							System.out.println(usuarios[i].getCPF());
							System.out.println(postos[h].getNome());
							System.out.println(postos[h].getDiasDaSemana(ag));
						}	
					}
				}
			}
		}
	}
	
	//realiza o agendamento o mais cedo possivel
	public void agendarCedo(String cpf) {
		int h = 0;
		int agp = 0;
		for(int i=0; i<a; i++) {
			if(cpf.equals(usuarios[i].getCPF()) == true) {
				if(usuarios[i].getIdade() > getIdadeMinimaAtendida()) {
					if(usuarios[i].getAgendado() == false) {
						
						for(int t = 0; t<p; t++) {
						    agp = postos[p].getDisponPerto();
							int menor = 1000;
							if(agp < menor) {
								h = t;
								menor = agp;
							}
						}
						
						usuarios[i].setAgendado(true);
						
						System.out.println("Comprovante de agendamento");
						System.out.println(usuarios[i].getCPF());
						System.out.println(postos[h].getNome());
						System.out.println(postos[h].getDiasDaSemana(agp));
							
					}
				}
			}
		}
	}
	
	//imprime os postos e seus dados
	public void imprimirPostos() {
		for(int i=0; i < p; i++) {
			System.out.println(postos[i].getNome());
			System.out.println(postos[i].getEndereco());
			postos[i].dia();
			postos[i].vagas();
		}
	}
	
	//imprime os usuarios e seus dados
	public void imprimirUsuarios() {
		for(int i=0; i<a; i++) {
			System.out.println(usuarios[i].getNome());
			System.out.println(usuarios[i].getCPF());
			System.out.println(usuarios[i].getAniversario());
			System.out.println(usuarios[i].getEndereco());
		}
	}


}
