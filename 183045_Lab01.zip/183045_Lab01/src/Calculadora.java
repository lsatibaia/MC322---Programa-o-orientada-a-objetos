import java.util.Scanner;

public class Calculadora {

	public int soma(int a, int b) {
		return a + b;
	}
	
	public int multiplicacao(int a, int b) {
		return a * b;
	}
	
	public int subtracao(int a, int b) {
		return a - b;
	}
	
	public int divisao(int a, int b) {
		return a / b;
	}
	
	public int fatorial(int a) {
		int f = a;
		while(a > 1) {
			f = f * (a - 1);
			a = a - 1;
		}
		return f;
	}
	
	public int primo(int a) {
		int p = 2;
		while(p < a) {
			if(a % p == 0) {
				return 0;
			}
			p = p + 1;
		}
		return 1;
	}
	

	public static void main (String[] args) {
		Calculadora x = new Calculadora();
		
		Scanner input = new Scanner(System.in);
		
		int numero;
		System.out.println("Digite 1 para somar");
		System.out.println("Digite 2 para subtrair");
		System.out.println("Digite 3 para multiplicar");
		System.out.println("Digite 4 para dividir");
		System.out.println("Digite 5 para calcular o fatorial");
		System.out.println("Digite 6 para verificar se um n�mero � primo");
		System.out.println("Qualquer outro valor para sair do programa");
		System.out.println("Digite a op��o escolhida: ");
		numero = input.nextInt();
		
		int a = 0;
		int b = 0;		
		while(numero != 7) {
			if(numero == 1) {
				System.out.println("Digite o primeiro n�mero: ");
				a = input.nextInt();
				System.out.println("Digite o segundo n�mero: ");
				b = input.nextInt();
				int resultado = x.soma(a, b);
				System.out.println("O resultado da soma �: " + resultado);
				
				System.out.println("Digite a nova op��o escolhida para continuar: ");
				numero = input.nextInt();
			}
			
			if(numero == 2) {
				System.out.println("Digite o primeiro n�mero: ");
				a = input.nextInt();
				System.out.println("Digite o segundo n�mero: ");
				b = input.nextInt();
				int resultado = x.subtracao(a, b);
				System.out.println("O resultado da subtra��o �: " + resultado);
				
				System.out.println("Digite a nova op��o escolhida para continuar: ");
				numero = input.nextInt();
			}
			
			if(numero == 3) {
				System.out.println("Digite o primeiro n�mero: ");
				a = input.nextInt();
				System.out.println("Digite o segundo n�mero: ");
				b = input.nextInt();
				int resultado = x.multiplicacao(a, b);
				System.out.println("O resultado da multiplica��o �: " + resultado);
				
				System.out.println("Digite a nova op��o escolhida para continuar: ");
				numero = input.nextInt();
			}
			
			if(numero == 4) {
				System.out.println("Digite o primeiro n�mero: ");
				a = input.nextInt();
				System.out.println("Digite o segundo n�mero: ");
				b = input.nextInt();
				int resultado = x.divisao(a, b);
				System.out.println("O resultado da divis�o �: " + resultado);
				
				System.out.println("Digite a nova op��o escolhida para continuar: ");
				numero = input.nextInt();
			}
			
			if(numero == 5) {
				System.out.println("Digite o n�mero: ");
				a = input.nextInt();
				int resultado = x.fatorial(a);
				System.out.println("O fatorial de " + a + " �: " + resultado);
				
				System.out.println("Digite a nova op��o escolhida para continuar: ");
				numero = input.nextInt();
			}
			
			if(numero == 6) {
				System.out.println("Digite o n�mero: ");
				a = input.nextInt();
				int resultado = x.primo(a);
				if(resultado == 0) {
					System.out.println(a + " n�o � primo");
				}
				if(resultado == 1) {
					System.out.println(a + " � primo");
				}
				
				System.out.println("Digite a nova op��o escolhida para continuar: ");
				numero = input.nextInt();
			}
		}
	}
}
