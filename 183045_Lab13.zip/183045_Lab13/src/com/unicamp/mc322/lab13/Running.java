package com.unicamp.mc322.lab13;

import java.time.LocalDate;
import java.time.Month;

public class Running {

	public static void main(String[] args) {
		ICrazyDS crazyDS = new MyCustomDS();
        //ICrazyDS crazyDS = new CrazyDS2();
        Pedidos order1 = new PedidosInternet(new User( "name1", "CPF1", LocalDate.of( 1985 , Month.JANUARY , 1 )), "AAA_2021");
        Pedidos order2 = new PedidosInternet(new User("name2", "CPF2", LocalDate.of( 1986 , Month.JANUARY , 2 )), "AAB_2021");
        Pedidos order3 = new PedidosInternet(new User("name3", "CPF3", LocalDate.of( 1987 , Month.JANUARY , 3 )), "AAC_2021");

        crazyDS.addElemento(order1);
        crazyDS.addElemento(order2);
        crazyDS.addElemento(order3);
        System.out.println("---- A: Elements ----");
        crazyDS.imprimirElementos();

        System.out.println("---- B: Getting and removing the element with highest priority ----");
        Pedidos p1;
        try {
            p1 = crazyDS.peekElemento();
            System.out.println("-selected element");
            p1.imprimirResumidoNome();
            crazyDS.removeElemento(p1);
            System.out.println("-elements");
            crazyDS.imprimirElementos();
        } catch (CrazyDSException e) {
            e.printStackTrace();
        }

        System.out.println("---- C: Adding an old person ----");
        Pedidos order4 = new PedidosInternet(new User("name3", "CPF", LocalDate.of( 1880 , Month.JUNE , 1 )), "AAD_2021");
        crazyDS.addElemento(order4);
        crazyDS.imprimirElementos();
        System.out.println("-selected element");
        IOrder p2 = crazyDS.peekElemento();
        p2.imprimirResumidoIdade();

        System.out.println("---- D: Checking an exception ----");
        try {
            Pedidos p3 = crazyDS.getPedidos(1000);
        } catch (CrazyDSException e) {
            //e.printStackTrace();
            System.out.println("-ok: Show error in logs");
        }
    }
}

