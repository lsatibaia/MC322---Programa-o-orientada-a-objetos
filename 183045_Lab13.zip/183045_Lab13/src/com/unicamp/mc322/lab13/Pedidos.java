package com.unicamp.mc322.lab13;

/**
 * superclasse que caracteriza os pontos necess�rios para cadastrar um pedido.
 * al�m de que implementa a interface IOrder.
 */
public class Pedidos implements IOrder {
	
	 	protected User pessoa;
	 	protected int nEspera;
	 	private String codigo;

	 	public Pedidos(User user, String codigo) {
	 		this.pessoa = user;
	 		this.nEspera = 0;
	 		this.codigo = codigo;
	 	}
	 	
	 	/**
	 	 * as proximas fun��es realizam a implementa��o da interface IOrder.
	 	 */
		@Override
		public void incrementarNEspera() {
			this.nEspera++;
		}

		@Override
		public int obterNEsepra() {
			return this.nEspera;
		}

		@Override
		public String obterCodigo() {
			return this.codigo;
		}

		@Override
		public void imprimirResumidoNome() {
			System.out.println(this.pessoa.getNome());
		}

		@Override
		public void imprimirResumidoCPF() {
			System.out.println(this.pessoa.getCPF());
		}

		@Override
		public void imprimirResumidoIdade() {
			System.out.println(this.pessoa.getIdade());
		}

		@Override
		public void imprimirCompleto() {
			System.out.println(this.pessoa.getNome());
			System.out.println(this.pessoa.getCPF());
			System.out.println(this.pessoa.getIdade());
		}

		@Override
		public User pessoa() {
			return this.pessoa;
		}
	 	
}
