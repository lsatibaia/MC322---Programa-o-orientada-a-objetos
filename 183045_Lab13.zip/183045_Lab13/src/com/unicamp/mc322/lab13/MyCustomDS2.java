package com.unicamp.mc322.lab13;

/**
 * 
 * classe que contem o segundo metodo de prioridade, metodo mais simples que o primeiro, a prioridade � pela ordem de chegada.
 *
 */
public class MyCustomDS2 implements ICrazyDS, IOrderingStrategy{

	private Pedidos[] lista;
	 
	/**
	 * nessa classe, ocorre a implementa��o de todas as fun��os de duas interfaces: ICrazyDS e IOrderingStrategy
	 * al�m disso, aqui ocorre o tratamento da exce��o da se a lista n�o for inicializada na fun��o main. 
	 */

	
	@Override
	public int calcularPrioridade(Pedidos pedido) {
		int x = this.lista.length;
		int y = 0;
		int z = 0;
		while(y < x) {
			if(this.lista[y] == pedido) {
				z = y + 1;
			}
			y++;
		}
		return z;
	}

	@Override
	public void addElemento(Pedidos pedido) {		
		try{
			int x = this.lista.length;
			this.lista[x] = pedido;
		}
		catch(ListaNaoInicializadaException e){
			Pedidos[] lista = new Pedidos[100];
			this.lista = lista;
			this.lista[0] = pedido;
		}	
	}

	@Override
	public void removeElemento(Pedidos pedido) {
		int x = this.lista.length;
		if(x == 0) {
			throw new RemocaoInvalidaException();
		}
		int y = 0;
		while(y < x) {
			if(this.lista[y] == pedido) {
				if(y + 1 == x) {
					this.lista[y] = null;
				}
				else {
					while(y + 1 < x) {
						this.lista[y] = this.lista[y + 1];
						y++;
					}
				}
			}
			y++;
		}
	}

	@Override
	public Pedidos peekElemento() {
		if(this.lista[0] != null) {
			return this.lista[0];
		}
		else {
			System.out.println("N�o h� pedidos!");
			return null;
		}
	}

	@Override
	public void imprimirElementos() {
		int x = lista.length;
		int y = 0;
		while(y + 1 < x) {
			System.out.println(this.lista[y]);
			y++;
		}
	}

	@Override
	public Pedidos getPedidos(int x) {
		return this.lista[x];
	}

}
