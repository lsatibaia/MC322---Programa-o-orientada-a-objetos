package com.unicamp.mc322.lab13;

/**
 * interface que define o m�todo para calcular a ordem de prioridade para atender os pedidos.
 *
 */

public interface IOrderingStrategy {

	public int calcularPrioridade(Pedidos pedido);
	
}
