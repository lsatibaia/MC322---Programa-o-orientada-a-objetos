package com.unicamp.mc322.lab13;

public class CrazyDSException extends NullPointerException {

	public CrazyDSException() {
		super();		
	}
	
	public CrazyDSException(String s) {
		super(s);
	}
	
	
}
