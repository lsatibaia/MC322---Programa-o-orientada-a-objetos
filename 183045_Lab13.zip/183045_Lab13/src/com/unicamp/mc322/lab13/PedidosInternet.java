package com.unicamp.mc322.lab13;

/**
 * subclasse de Pedidos, apenas para separar os pedidos realizados pela internet e os pedidos feitos na loja
 *
 */
public class PedidosInternet extends Pedidos{

	public PedidosInternet(User user, String codigo) {
		super(user, codigo);
	}

}
