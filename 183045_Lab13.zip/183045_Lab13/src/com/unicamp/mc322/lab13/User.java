package com.unicamp.mc322.lab13;

import java.time.LocalDate;
import java.time.Period;

/**
 * 
 * classe da pessoa que realizar� o pedido, a classe da as caracteristicas pertencentes a esse usu�rio
 *
 */
public class User {

	private String nome;
	private String CPF;
	private LocalDate idade;
	
	public User(String nome, String CPF, LocalDate idade) {
		this.nome = nome;
		this.CPF = CPF;
		this.idade = idade;
	}
	
	/**
	 * retorna o nome do usuario
	 * @return
	 */
	public String getNome() {
		return this.nome;
	}
	
	/**
	 * retorna o CPF do usuario
	 * @return
	 */
	public String getCPF() {
		return this.CPF;
	}
	
	/**
	 * retorna a idade (anos) do usuario
	 * @return
	 */
	public int getIdade() {
		int x = 0;
		x = Period.between(LocalDate.of( this.idade.getYear() , this.idade.getMonth() , this.idade.getDayOfMonth() ), LocalDate.now()).getYears();
		return x;
	}
}
