package com.unicamp.mc322.lab13;

public class ListaNaoInicializadaException extends NullPointerException{

	/**
	 * classe que define a exce��o de quando n�o se inicia um array e tenta mexer nele, ela � uma subclasse da exce��o de ponterio nulo.
	 */
	private static final long serialVersionUID = 1L;

	public ListaNaoInicializadaException() {
		super();		
	}
	
	public ListaNaoInicializadaException(String s) {
		super(s);
	}
	
}
