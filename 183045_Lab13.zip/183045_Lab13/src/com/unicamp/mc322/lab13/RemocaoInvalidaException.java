package com.unicamp.mc322.lab13;

public class RemocaoInvalidaException extends IllegalArgumentException {

	/**
	 * classe que define a exce��o de quando tenta apagar um vetor nulo, ela � uma subclasse da exce��o de argumento ilegal.
	 */
	private static final long serialVersionUID = 1L;

	public RemocaoInvalidaException() {
		super();		
	}
	
	public RemocaoInvalidaException(String s) {
		super(s);
	}
	
	public RemocaoInvalidaException(Throwable cause) {
		super(cause);
	}
	
	public RemocaoInvalidaException(String s, Throwable cause) {
		super(s, cause);
	}
}
