package com.unicamp.mc322.lab13;

/**
 * interface que define alguns m�todos que necessitam ser realizados para os pedidos.
 *
 */

public interface IOrder {
	
	public void incrementarNEspera();
	
	public int obterNEsepra();
	
	public String obterCodigo();
	
	public void imprimirResumidoNome();
	public void imprimirResumidoCPF();
	public void imprimirResumidoIdade();
	
	public void imprimirCompleto();
	
	public User pessoa();
	
}
