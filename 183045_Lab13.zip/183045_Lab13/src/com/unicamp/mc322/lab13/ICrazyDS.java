package com.unicamp.mc322.lab13;

/**
 * interface que define alguns m�todos que ser�o usados para compor a lista de pedidos e consequentemente organizar�o sua ordem segundo os comandos da outra interface (IOrderingStrategy).
 *
 */

public interface ICrazyDS {

	public void addElemento(Pedidos pedido);
	
	public void removeElemento(Pedidos pedido);
	
	public Pedidos peekElemento();
	
	public void imprimirElementos();

	public Pedidos getPedidos(int i);
	
}
