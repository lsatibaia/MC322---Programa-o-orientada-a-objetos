package com.unicamp.mc322.lab13;

/**
 * 
 * classe que cont�m o primeiro m�todo de prioridade, que no caso � o priorityScore, dado no enunciado do laborat�rio.
 *
 */

public class MyCustomDS implements ICrazyDS, IOrderingStrategy {

	private Pedidos[] lista;
	private int x = 0;
	
	/**
	 * nessa classe, ocorre a implementa��o de todas as fun��os de duas interfaces: ICrazyDS e IOrderingStrategy
	 * al�m disso, aqui ocorre o tratamento da exce��o da se a lista n�o for inicializada na fun��o main. 
	 */
	@Override
	public void addElemento(Pedidos pedido) {	
		if(this.x == 0) {
			Pedidos[] lista = new Pedidos[10000];
			this.lista = lista;
			this.lista[0] = pedido;
			this.x++;
		}
		
		
		try{
			this.lista[this.x] = pedido;
			this.x++;
			if(x == 0) {
				return;
			}
			else {
				organizarLista();
				return;
			}
		}catch(ListaNaoInicializadaException e){
			Pedidos[] lista = new Pedidos[100];
			this.lista = lista;
			this.lista[0] = pedido;
		}
		
	}

	@Override
	public void removeElemento(Pedidos pedido) {
		if(x == 0) {
			throw new RemocaoInvalidaException();
		}
		int y = 0;
		while(y < this.x) {
			if(this.lista[y] == pedido) {
				if(y + 1 == this.x) {
					this.lista[y] = null;
				}
				else {
					while(y + 1 < this.x) {
						this.lista[y] = this.lista[y + 1];
						y++;
					}
					this.lista[y + 1] = null;
				}
			}
			y++;
		}
		this.x--;
		y = 0;
		while(y < this.x) {
			this.lista[y].nEspera ++;
			y++;
		}
		organizarLista();
	}
	
	private void organizarLista() {
		int y = 0;
		while(y + 1 < this.x) {
			int z = 0;
			while(z + 2 < this.x) {
				if(priorityScore(this.lista[z]) < priorityScore(this.lista[z + 1])) {
					Pedidos p = this.lista[z];
					this.lista[z] = this.lista[z + 1];
					this.lista[z + 1] = p;
				}
				z++;
			}
			y++;
		}
	}
	
	private int priorityScore(Pedidos p) {
		int e = 0;
		e = (p.pessoa.getIdade() / 100) + ((7/100) * p.nEspera);
		return e;
	}

	@Override
	public Pedidos peekElemento() {
		if(this.lista[0] != null) {
			return this.lista[0];
		}
		else {
			System.out.println("N�o h� pedidos!");
			return null;
		}
	}

	@Override
	public void imprimirElementos() {
		int y = 0;
		while(y + 1 < this.x) {
			System.out.println(this.lista[y]);
			y++;
		}
	}

	@Override
	public int calcularPrioridade(Pedidos pedido) {
		int y = 0;
		int z = 0;
		while(y + 1 < this.x) {
			if(this.lista[y] == pedido) {
				z = y + 1;
			}
			y++;
		}
		return z;
	}
	
	public Pedidos getPedidos(int x) {
		return this.lista[x];
	}

}
