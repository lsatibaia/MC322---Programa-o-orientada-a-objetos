package com.unicamp.mc322.lab10;

public class Viagem {
	private ArmazenamentoUsuario user;
	private ArmazenamentoUsuario user2;
	private ArmazenamentoMotorista motorista;
	private Veiculos carro;
	private int distancia;
	private Parada parada;
	private double valor;
	
	/**
	 * cria a viagem que foi programada em primeiro lugar. levando em conta o usuario que pediu o
	 * transporte, o motorista e a distancia
	 * @param user
	 * @param user2
	 * @param motorista
	 * @param carro
	 * @param distancia
	 */
	public Viagem(ArmazenamentoUsuario user, ArmazenamentoUsuario user2, ArmazenamentoMotorista motorista, Veiculos carro, int distancia) {
		this.user = user; 
		this.user2 = user2;
		this.motorista = motorista;
		this.carro = carro;
		this.distancia = distancia;
	}
	
	/**
	 * associa a viagem com as paradas
	 * @param user
	 * @param user2
	 * @param viagem
	 * @param totalParadas
	 */
	public void Parada(ArmazenamentoUsuario user, ArmazenamentoUsuario user2, Viagem viagem, int totalParadas) {
		viagem.parada = new Parada();
		viagem.parada.user = user;
		viagem.parada.user2 = user2;
		viagem.parada.setTotalParadas(totalParadas);
		
		calcularValor(user, user2, viagem, parada);
	}
	
	
	
	/**
	 * calcula o valor total da viagem, levando em conta as paradas e as distancias
	 * imprime todos os dados necessarios ap�s a viagem
	 * @param user
	 * @param user2
	 * @param viagem
	 * @param parada
	 */
	private void calcularValor(ArmazenamentoUsuario user, ArmazenamentoUsuario user2, Viagem viagem, Parada parada) {
		valor = viagem.carro.getPrecoFixo();
		valor = valor + (viagem.distancia / 100) * viagem.carro.getPrecoCemMetros();
		valor = valor + (parada.getTotalParadas() * viagem.carro.getPrecoParada());
		

		
		System.out.println("Resumo da viagem:");
		if(user2 == null) {
			System.out.println("Passageiro(s): " + user.getNome());
		}
		if(user2 != null) {
			System.out.println("Passageiro(s): " + user.getNome() + " e " + user2.getNome());
		}
		System.out.println("Motorista: " + motorista.getNome());
		System.out.println("Dist�ncia percorrida: " + distancia + " metros");
		System.out.println("Quantidade de paradas: " + parada.getTotalParadas());
		System.out.println("Pre�o final da viagem: R$" + valor);
		System.out.println();
	}

	/**
	public ArmazenamentoUsuario getUser() {
		return this.user;
	}
	**/
	
	public ArmazenamentoMotorista getMotorista() {
		return this.motorista;
	}
	
	public Veiculos getCarro() {
		return this.carro;
	}
	
	public int getDistancia() {
		return this.distancia;
	}
}
