package com.unicamp.mc322.lab10;

public class ArmazenamentoMotorista extends ArmazenamentoUsuario {
	
	private int habilitacao;
	Veiculos[] carros;
	
	/**
	 * classe do motorista do aplicativo, sendo uma subclasse de armazenamento do usuario
	 * @param nome
	 * @param CPF
	 * @param nascimento
	 * @param cartao
	 * @param habilitacao
	 * @param nCarros
	 */
	public ArmazenamentoMotorista(String nome, int CPF, int nascimento, int cartao, int habilitacao, int nCarros) {
		super(nome, CPF, nascimento, cartao);
		this.habilitacao = habilitacao;
		
		Veiculos[] carros = new Veiculos[nCarros];
		
		for (int i = 0; i < nCarros; i++) {
			carros[i] = new Veiculos(); 
		}
		this.carros = carros;
	}
	
	/**
	 * composicao com os veiculos, criando uma lista de carros para o motorista
	 * @param motorista
	 * @param n
	 * @param ano
	 * @param placa
	 * @param luxo
	 */
	public void addVeiculo(ArmazenamentoMotorista motorista, int n, int ano, String placa, boolean luxo){
		motorista.carros[n].ano = ano;
		motorista.carros[n].placa = placa;
		motorista.carros[n].luxo = luxo;
		
		if(luxo == true) {
			motorista.carros[n].precoFixo = 7;
			motorista.carros[n].precoCemMetros = 3.5;
			motorista.carros[n].precoParada = 2.7;
		}
		else {
			motorista.carros[n].precoFixo = 3;
			motorista.carros[n].precoCemMetros = 2;
			motorista.carros[n].precoParada = 1.5;
		}
		
		carros[n].atribuirProprietario(motorista);
	}
	
	
	public int getHabilitacao() {
		return this.habilitacao; 
	}

	public Veiculos[] getCarros() {
		return carros;
	}

	public void setCarros(Veiculos[] carros) {
		this.carros = carros;
	}
	
}
