package com.unicamp.mc322.lab10;

public class Veiculos {
	
	/**
	 * classe dos carros que o motorista possui. j� que se o motorista deixar de usar o aplicativo 
	 * n�o faria sentido deixar seus carros ainda no app. logo, a relacao entre o motorista e o 
	 * veiculo � de composi��o.
	 * sendo assim, a classe veiculo foi criada mas a lista de veiculos fica na classe do motorista,
	 * para que se ele sair, os veiculos saiam junto
	 */
	
	protected int ano;
	protected String placa;
	protected boolean luxo;
	protected double precoFixo;
	protected double precoCemMetros;
	protected double precoParada;
	
	private ArmazenamentoMotorista motorista;
	
	public void atribuirProprietario(ArmazenamentoMotorista motorista) {
		this.motorista = motorista;
	}
	
	public ArmazenamentoMotorista getMotorista() {
		return this.motorista;
	}
	
	public void setAno(int ano) {
		this.ano = ano;
		return;
	}
	
	public void setPlaca(String placa) {
		this.placa = placa;
		return;
	}
	
	
	public int getAno() {
		return this.ano;
	}
	
	public String getPlaca() {
		return this.placa;
	}
	
	public boolean getLuxo() {
		return this.luxo;
	}
	
	public double getPrecoFixo() {
		return this.precoFixo;
	}
	
	public double getPrecoCemMetros() {
		return this.precoCemMetros;
	}
	
	public double getPrecoParada() {
		return this.precoParada;
	}
}
