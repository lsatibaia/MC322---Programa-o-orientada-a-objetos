package com.unicamp.mc322.lab10;

public class Main {

	public static void main(String args[]) {
		/**
		 * classe running que possui a fun��o main e roda o projeto pedido para o trabalho
		 */
		ArmazenamentoUsuario user = new ArmazenamentoUsuario("Marcos", 145678798, 15/07/1998, 369874);
		ArmazenamentoMotorista motorista = new ArmazenamentoMotorista("Maria", 248679108, 12/02/1997, 483530, 987654, 2);
		ArmazenamentoUsuario user2 = new ArmazenamentoUsuario("Jo�o", 654973652, 03/01/2002, 785632);
		
		motorista.addVeiculo(motorista, 0, 2009, "ABC-1234", true);
		motorista.addVeiculo(motorista, 1, 2013, "OOP-2020", false);
		
		Viagem viagem1 = new Viagem(user, null, motorista, motorista.carros[0], 500);
		viagem1.Parada(user, null, viagem1, 2);
		
		Viagem viagem2 = new Viagem(user, user2, motorista, motorista.carros[1], 2000);
		viagem2.Parada(user, user2, viagem2, 5);
		
		Viagem viagem3 = new Viagem(user2, null, motorista, motorista.carros[0], 700);
		viagem3.Parada(user2, null, viagem3, 3);
	}

}