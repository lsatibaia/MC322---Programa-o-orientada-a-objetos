package com.unicamp.mc322.lab10;

public class Parada {
	/**
	 * classe que realiza as paradas durante a viagem, j� que elas n�o s�o marcadas no inicio 
	 * da viagem
	 */
	protected ArmazenamentoUsuario user;
	protected ArmazenamentoUsuario user2;
	protected int totalParadas;
	
	public ArmazenamentoUsuario getUser() {
		return user;
	}
	public void setUser(ArmazenamentoUsuario user) {
		this.user = user;
	}
	
	
	
	public int getTotalParadas() {
		return totalParadas;
	}
	public void setTotalParadas(int totalParadas) {
		this.totalParadas = totalParadas;
	}
	public ArmazenamentoUsuario getUser2() {
		return user2;
	}
	public void setUser2(ArmazenamentoUsuario user2) {
		this.user2 = user2;
	}
	

 
	
}
