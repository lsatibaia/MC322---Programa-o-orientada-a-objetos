package com.unicamp.mc322.lab10;

public class ArmazenamentoUsuario {
	private String nome;
	private int CPF;
	private int nascimento;
	private int cartao;
	
	/**
	 * classe do usuario do aplicativo, o cliente que usara o uber
	 * @param nome
	 * @param CPF
	 * @param nascimento
	 * @param cartao
	 */
	public ArmazenamentoUsuario(String nome, int CPF, int nascimento, int cartao) {
		this.nome = nome;
		this.CPF = CPF;
		this.nascimento = nascimento;
		this.cartao = cartao; 
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getCPF() {
		return this.CPF;
	}
	
	public int getNascimento() {
		return this.nascimento;
	}
	
	public int getCartao() {
		return this.cartao;
	}
	
	
}
